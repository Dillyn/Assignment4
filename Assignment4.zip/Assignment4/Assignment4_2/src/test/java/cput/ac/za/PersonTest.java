package cput.ac.za;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class PersonTest {

    @Test
    public void getSalary() {
        Person person = new Person();


        Assert.assertEquals(1000, person.getSalary());
    }
}