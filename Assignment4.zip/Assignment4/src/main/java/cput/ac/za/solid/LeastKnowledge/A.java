package cput.ac.za.solid.LeastKnowledge;

public class A {
    private B b = new B();

    public B getB()
    {
        return b;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private String name = "Dillyn";


}

