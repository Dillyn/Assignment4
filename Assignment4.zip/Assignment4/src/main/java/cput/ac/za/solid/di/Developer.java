package cput.ac.za.solid.di;

public interface Developer {

    String develop();
}
