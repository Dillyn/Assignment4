package cput.ac.za.solid.di;

public class FrontEndDeveloper implements Developer {

    @Override
    public String develop() {
      return  writeJavascript();
    }
    //not making use of the dependency inversion principle
    public String writeJavascript() {
        return"writeJavascript";
    }


}
