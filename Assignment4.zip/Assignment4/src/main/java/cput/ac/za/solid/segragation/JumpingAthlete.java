package cput.ac.za.solid.segragation;

public interface JumpingAthlete extends Athlete {

    void highJump();

    void longJump();

}
