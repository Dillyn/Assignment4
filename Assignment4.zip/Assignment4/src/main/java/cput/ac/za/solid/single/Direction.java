package cput.ac.za.solid.single;

public enum Direction {
    N,W,S,E
}
