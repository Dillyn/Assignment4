package cput.ac.za.solid.di;

public class BackEndDeveloper implements Developer {

    @Override
    public String develop() {
       return writeJava();
    }
    //making use of the dependency inversion principle
    private String writeJava() {
        return "writeJava";
    }


}
