package cput.ac.za.solid.segragation;

public interface Athlete2 {
    void compete();

    void swim();

    void run();

    void jump();

    void shotput();
}
