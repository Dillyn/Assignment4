package cput.ac.za.solid.LeastKnowledge;

public class B extends A {

    private C c = new C();

    public C  getC()
    {
        return c;
    }

}
