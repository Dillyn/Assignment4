package cput.ac.za.solid.liskov;

public  class Shapes {
    private int length;
    private  int width;

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int area(int a,int b){
        return a * b;
    }
   public int volume(int a,int b,int c){
    return a * b* c;
   }
}
