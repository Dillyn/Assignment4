package cput.ac.za.solid.LeastKnowledge;

public class LeastKnowledge {
}
