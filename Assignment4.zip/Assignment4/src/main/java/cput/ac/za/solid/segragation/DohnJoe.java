package cput.ac.za.solid.segragation;

public class DohnJoe implements Athlete2 {
   //This violate interface segregation principle because it allows an object
   // to assume many roles
    @Override
    public void compete(){
        System.out.println("I compete");
    }

    @Override
    public void swim(){
        System.out.println("I swim");
    }
    @Override
    public void run(){
        System.out.println("I run");
    }
    @Override
    public void jump(){
        System.out.println("I jump");
    }
    @Override
    public void shotput(){
        System.out.println("I shotput");
    }
}
