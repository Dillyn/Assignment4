package cput.ac.za.solid.liskov;

public interface NonWorkingEmployee {

    String relax();
}
