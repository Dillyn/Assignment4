package cput.ac.za.solid.liskov;

public class Square extends Shapes {


}
