package cput.ac.za.solid.LeastKnowledge;

public class C extends B {
    // this violates principle of least knowledge because C can talk to B's neighbour which is A
}
