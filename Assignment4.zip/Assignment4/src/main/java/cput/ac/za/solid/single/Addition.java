package cput.ac.za.solid.single;
// this violate the principle of single responsibility, because it has multiple responsibilities
// and has more than one reason to change
public class Addition {
    public int add(int a,int b){
        return a+b;
    }
    public int subtract(int a,int b){
        return a-b;
    }
    public int divide(int a,int b){
        return a/b;
    }
    public int multiply(int a,int b){
        return a*b;
    }
}
