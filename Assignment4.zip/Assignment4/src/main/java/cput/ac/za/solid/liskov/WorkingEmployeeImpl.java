package cput.ac.za.solid.liskov;

public class WorkingEmployeeImpl extends Employee implements WorkingEmployee {

    @Override
    public String work() {
        return "I am working";

    }
}
