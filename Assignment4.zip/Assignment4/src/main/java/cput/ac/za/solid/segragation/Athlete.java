package cput.ac.za.solid.segragation;

public interface Athlete {

    void compete();

}
