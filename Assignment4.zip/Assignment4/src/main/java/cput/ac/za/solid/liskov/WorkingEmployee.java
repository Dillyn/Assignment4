package cput.ac.za.solid.liskov;

public interface WorkingEmployee {

    String work();
}
