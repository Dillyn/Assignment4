package cput.ac.za.solid.LeastKnowledge;

public class D extends A {
    // this does not violate the principle of least knowledge because D is A's neighbour
}
