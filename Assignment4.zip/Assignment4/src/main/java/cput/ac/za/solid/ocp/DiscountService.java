package cput.ac.za.solid.ocp;

import java.math.BigDecimal;

public class DiscountService {
// Violates the open/closed rule because it is modifying the strategy
    public BigDecimal applyDiscounts(BigDecimal price, Discount[] discounts) {

        BigDecimal discountPrice = price.add(BigDecimal.ZERO);

        for(Discount discount:discounts) {

       //     discountPrice = discount.apply(discounts);
        }

        return discountPrice;
    }
}
