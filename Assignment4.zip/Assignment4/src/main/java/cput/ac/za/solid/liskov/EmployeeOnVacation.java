package cput.ac.za.solid.liskov;

public class EmployeeOnVacation implements NonWorkingEmployee {

    @Override
    public String relax() {
        return "I am relaxing";

    }
}
