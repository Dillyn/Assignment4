package cput.ac.za.solid.segragation;

public interface SwimmingAthlete extends Athlete {

    void swim();

}
