package cput.ac.za.solid.liskov;

public class Employee {

    public String getTitle() {
        return "The employee's title";
    }

}
