package cput.ac.za.solid.LeastKnowledge;

import org.junit.Test;

import static org.junit.Assert.*;

public class BTest {

    @Test
    public void test1() {
        // this violates principle of least knowledge because C can
        // talk to B's neighbour which is A and A can talk to C which is B's neighbour

        A a = new A();
        System.out.println(a.getB().getC().getB().getC().getName());
    }
}