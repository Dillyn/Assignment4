package cput.ac.za.solid.liskov;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class SquareTest {
//Violates liskov principle because a square does not have volume
//No new Exceptions can be thrown by the subtype
    @Test
    public void volumeTest(){
        Square square = new Square();

        Assert.assertEquals(8, square.volume(2,2,2));
    }

}