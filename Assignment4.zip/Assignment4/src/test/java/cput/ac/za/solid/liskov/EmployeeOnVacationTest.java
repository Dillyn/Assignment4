package cput.ac.za.solid.liskov;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class EmployeeOnVacationTest {

    @Test
    public void relax() {
        EmployeeOnVacation emp = new EmployeeOnVacation();

        Assert.assertEquals("I am relaxing",emp.relax());
    }
}