package cput.ac.za.solid.di;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class FrontEndDeveloperTest {

    //not making use of the dependency inversion principle
    @Test
    public void develop() {
        FrontEndDeveloper frontDev = new FrontEndDeveloper();



        Assert.assertEquals("writeJavascript" , frontDev.writeJavascript());
    }

    //not properly making use of the dependency inversion principle because previous method is accessible
    @Test
    public void develop1() {
        FrontEndDeveloper frontDev = new FrontEndDeveloper();



        Assert.assertEquals("writeJavascript" , frontDev.develop());
    }
}