package cput.ac.za.solid.ocp;

import org.junit.Assert;
import org.junit.Test;
import java.math.BigDecimal;
import java.text.DecimalFormat;


import static org.junit.Assert.*;

public class AdultDiscountTest {

        DecimalFormat formatter = new DecimalFormat("#0.00");



    @Test
    public void apply() {

        AdultDiscount adult = new AdultDiscount();
//I struggled with getting 90 to show as 90.00 kept truncating to 90.0
        Assert.assertEquals(90.00,adult.apply(BigDecimal.valueOf(100)));
    }
}