package cput.ac.za.solid.LeastKnowledge;

import org.junit.Test;

import static org.junit.Assert.*;

public class DTest {
    @Test
    public void test1() {
        // this does not violate the principle of least knowledge because D is A's neighbour
        D d = new D();
        System.out.println(d.getName());
    }

}