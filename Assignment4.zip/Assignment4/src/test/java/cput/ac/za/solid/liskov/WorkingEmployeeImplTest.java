package cput.ac.za.solid.liskov;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class WorkingEmployeeImplTest {

    @Test
    public void work() {
        WorkingEmployeeImpl emp = new WorkingEmployeeImpl();


        Assert.assertEquals("I am working",emp.work());
    }

    @Test
    public void work1() {
        WorkingEmployeeImpl emp = new WorkingEmployeeImpl();


        Assert.assertEquals("The employee's title",emp.getTitle());
    }
}