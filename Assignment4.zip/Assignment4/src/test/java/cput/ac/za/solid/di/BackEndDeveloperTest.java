package cput.ac.za.solid.di;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class BackEndDeveloperTest {
    //making use of the dependency inversion principle
    @Test
    public void develop() {
        BackEndDeveloper backDev = new BackEndDeveloper();


        Assert.assertEquals("writeJava" , backDev.develop());

    }

}