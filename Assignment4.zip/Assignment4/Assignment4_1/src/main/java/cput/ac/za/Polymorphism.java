package cput.ac.za;

public class Polymorphism {

    public int area(int a, int b){
       return a;
    }
}
