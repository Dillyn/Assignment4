package cput.ac.za;

public class Daughter extends Inheritance{


}
