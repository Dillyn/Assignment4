package cput.ac.za;

public class Square extends Polymorphism {

    @Override
    public int area(int a, int b){
        return  a*b;

    }

}
