package cput.ac.za;

public class Inheritance {

    public String Inherit(){
        return "I got it from my momma";
    }

}


