package cput.ac.za;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class EncapsulationTest {

    @Test
    public void ecapsulationTest(){
        Encapsulation encap = new Encapsulation();
        encap.setName("Dillyn");

        Assert.assertEquals("Dillyn", encap.getName());
    }

}