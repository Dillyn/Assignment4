package cput.ac.za;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class SquareTest {

    @Test
    public void area() {
        Polymorphism square = new Square();

        Assert.assertEquals(4, square.area(2,2));
    }
}