package cput.ac.za;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class DaughterTest {
    @Test
    public void testInheritance(){
        Daughter daughter = new Daughter();

        Assert.assertEquals("I got it from my momma", daughter.Inherit());
    }

}